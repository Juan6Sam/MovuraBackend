# MovuraBackend

Resumen rápido
- Backend en .NET (ASP.NET Core) para Movura.
- Estructura principal: `src/Movura.Api`
- Este repo necesita limpieza de secretos y mejoras de CI/test.
